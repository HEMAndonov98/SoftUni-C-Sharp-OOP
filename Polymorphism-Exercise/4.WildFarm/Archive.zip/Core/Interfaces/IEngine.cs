﻿using System;
namespace WildFarm.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}

