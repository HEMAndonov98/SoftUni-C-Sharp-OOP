﻿using System;
namespace Raiding.Models.Abilitymessages
{
    public static class AbilityMsg
    {
        //{0} -> Type | {1} -> Name | {2} -> Power
        public const string healedMsg = "{0} - {1} healed for {2}";
        public const string damageMsg = "{0} - {1} hit for {2} damage";
    }
}

