﻿using System;
namespace Raiding.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string input);
    }
}

