﻿using System;
namespace Raiding.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}

