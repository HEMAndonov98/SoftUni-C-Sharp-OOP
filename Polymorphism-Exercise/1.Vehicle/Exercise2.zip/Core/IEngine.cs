﻿using System;
namespace Vehicle.Core
{
    public interface IEngine
    {
        public void Run();
    }
}

