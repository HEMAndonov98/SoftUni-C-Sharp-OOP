﻿using System;
namespace Person
{
	public class Child : Person
	{
		public Child(string name, int age) : base(name, age)
		{
		}
    }
}

