﻿using System;
namespace Restaurant
{
	public class Soup : Starter
	{
		public Soup(string name, decimal price, double grams) : base(name, price, grams)
        {
		}
	}
}

