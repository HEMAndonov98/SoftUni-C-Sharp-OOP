﻿using System;
namespace _3.ShoppingSpree
{
	public abstract class ExceptionMessages
	{
		public const string EmptyNameException = "Name cannot be empty";
		public const string NegativeMoneyValue = "Money cannot be negative";
	}
}

