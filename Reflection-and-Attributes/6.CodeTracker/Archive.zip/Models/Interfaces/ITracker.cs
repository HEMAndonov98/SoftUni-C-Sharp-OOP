﻿namespace AuthorProblem.Models.Interfaces
{
    public interface ITracker
    {
        void PrintMethodsByAuthor();
    }
}