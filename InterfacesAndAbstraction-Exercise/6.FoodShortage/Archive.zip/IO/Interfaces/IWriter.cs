﻿using System;
namespace FoodShortage.IO.Interfaces
{
    public interface IWriter
    {
        public void WriteLine(string text);
    }
}

