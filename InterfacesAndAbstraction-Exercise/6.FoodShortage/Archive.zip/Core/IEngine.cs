﻿using System;
namespace FoodShortage.Core
{
    public interface IEngine
    {
        public void Run();
    }
}

