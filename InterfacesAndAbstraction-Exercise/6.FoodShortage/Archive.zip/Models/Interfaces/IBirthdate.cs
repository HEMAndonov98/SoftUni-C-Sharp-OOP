﻿using System;
namespace FoodShortage.Models.Interfaces
{
    public interface IBirthdate
    {
        public string Birthdate { get; }
    }
}

