﻿using System;
namespace FoodShortage.Models.Interfaces
{
    public interface IIdentifiable
    {
        public string Id { get; }
    }
}

