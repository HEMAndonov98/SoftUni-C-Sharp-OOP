﻿using System;
namespace BorderControl.Models.Interfaces
{
    public interface IIdentifiable
    {
        public string Id { get; }
    }
}

