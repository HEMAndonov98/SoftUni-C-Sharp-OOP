﻿using System;
namespace BorderControl.Core
{
    public interface IEngine
    {
        public void Run();
    }
}

