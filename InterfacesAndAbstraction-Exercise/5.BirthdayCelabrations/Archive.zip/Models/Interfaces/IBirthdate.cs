﻿using System;
namespace BirthdayCelabrations.Models.Interfaces
{
    public interface IBirthdate
    {
        public string Birthdate { get; }
    }
}

