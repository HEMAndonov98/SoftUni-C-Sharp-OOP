﻿using System;
namespace BirthdayCelabrations.Models.Interfaces
{
    public interface IIdentifiable
    {
        public string Id { get; }
    }
}

