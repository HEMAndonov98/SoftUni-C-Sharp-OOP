﻿using System;
namespace BirthdayCelabrations.Core
{
    public interface IEngine
    {
        public void Run();
    }
}

