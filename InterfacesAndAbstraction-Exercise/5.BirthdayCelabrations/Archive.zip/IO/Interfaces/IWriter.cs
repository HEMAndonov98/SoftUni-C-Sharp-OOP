﻿using System;
namespace BirthdayCelabrations.IO.Interfaces
{
    public interface IWriter
    {
        public void WriteLine(string text);
    }
}

