﻿using System;
namespace BirthdayCelabrations.IO.Interfaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}

