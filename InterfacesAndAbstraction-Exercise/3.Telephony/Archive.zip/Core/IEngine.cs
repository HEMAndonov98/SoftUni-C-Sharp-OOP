﻿using System;
namespace Telephony.Core
{
    public interface IEngine
    {
        public void Run();
    }
}

