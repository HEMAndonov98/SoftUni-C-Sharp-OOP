﻿using System;
namespace Telephony.Models.Interfaces
{
    public interface IBrowsable
    {
        public string Browse(string website); 
    }
}

